#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future

http=127.0.0.1:8080 # 这里修改成你的服务器地址:UnblockNeteaseMusic http 端口
https=127.0.0.1:8081 # 这里修改成你的服务器地址:UnblockNeteaseMusic http 端口
re=$(grep -m1 -i "com.netease.cloudmusic" /data/system/packages.list | cut -d' ' -f2)
iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner $re -m tcp --dport 80  -j DNAT --to-destination $http
iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner $re -m tcp --dport 443 -j DNAT --to-destination $https

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
